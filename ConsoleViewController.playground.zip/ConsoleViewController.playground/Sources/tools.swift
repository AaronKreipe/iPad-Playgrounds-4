import UIKit
import PlaygroundSupport

//MARK: draw vertical lines
extension CGPath{
    static func verticalLines(origin: CGPoint, spacing: CGFloat, count: Int, length: CGFloat, decrement: CGFloat = 0)->CGPath{
        var origin = origin
        var end = CGPoint(x: origin.x, y: origin.y + length)
        let m = CGMutablePath()
        for _ in 0..<count{
            m.move(to: origin)
            m.addLine(to: end)
            origin.x += spacing
            origin.y += decrement
            end.x = origin.x
            end.y -= decrement
        }
        return m
    }
}

//MARK: draw a partially rounded rect
extension CGRect{
    enum CornerMask: Int{
        case maxXmaxY
        case maxXMinY
        case minXmaxY
        case minXminY
    }
    func path(radius: CGFloat = 0,  mask: Set<CornerMask> = [.maxXmaxY, .maxXMinY, .minXminY, .minXmaxY])->CGPath{
        var mask = mask
        if radius == 0{
            mask = []
        }
        var p = origin
        let m = CGMutablePath()
        m.move(to: p)
        if mask.contains(.minXminY){
            p = CGPoint(x: minX + radius, y: minY)
            m.move(to: p)
            p = CGPoint(x: minX, y: minY)
            m.addArc(tangent1End: p, tangent2End: CGPoint(x: minX, y: minY + radius) , radius: radius)
        }
        if mask.contains(.minXmaxY){
            p = CGPoint(x: minX, y: maxY - radius)
            m.addLine(to: p)
            p = CGPoint(x: minX, y: maxY)
            m.addArc(tangent1End: p, tangent2End: CGPoint(x: minX + radius, y: maxY), radius: radius)
        }else{
            p = CGPoint(x: minX, y: maxY)
            m.addLine(to: p)
        }
        if mask.contains(.maxXmaxY){
            p = CGPoint(x: maxX - radius, y: maxY)
            m.addLine(to: p)
            p = CGPoint(x: maxX, y: maxY)
            m.addArc(tangent1End: p, tangent2End: CGPoint(x: maxX, y: maxY - radius), radius: radius)
        }else{
            p = CGPoint(x: maxX, y: maxY)
            m.addLine(to: p)
        }
        if mask.contains(.maxXMinY){
            p = CGPoint(x: maxX, y: minY + radius)
            m.addLine(to: p)
            p = CGPoint(x: maxX, y: minY)
            m.addArc(tangent1End: p, tangent2End: CGPoint(x: maxX - radius, y: minY), radius: radius)
        }else{
            p = CGPoint(x: maxX, y: minY)
            m.addLine(to: p)
        }
        m.closeSubpath()
        return m
    }
}

//MARK: just a little grabber
final class GrabberView: UIView{
    convenience init(){
        self.init(frame: CGRect(x: 0, y: 0, width: 50, height: 60))
    }
    var fillColor = UIColor.darkGray.withAlphaComponent(0.3)
    var strokeColor = UIColor.darkGray.withAlphaComponent(0.7)
    override func draw(_ rect: CGRect) {
        fillColor.setFill()
        UIBezierPath(cgPath: bounds.path(radius: 16, mask: [.minXmaxY, .minXminY])).fill()
        strokeColor.setStroke()
        UIBezierPath(cgPath: CGPath.verticalLines(origin: CGPoint(x: 15, y: 15), spacing: 8, count: 4, length: 30, decrement: 1.5).copy(strokingWithWidth: 3, lineCap: .round, lineJoin: .round, miterLimit: 0)).stroke()
    }
}

//MARK: Console
final public class ConsoleViewController: UIViewController{
    public var liveView: PlaygroundLiveViewable?{
        didSet{setup(with: liveView)}
    }
    public var fontAttributes: [NSAttributedStringKey: Any] = [:]{
        didSet{textView.attributedText = NSAttributedString(string: text, attributes: fontAttributes)}
    }
    public var backgroundColor: UIColor = .white{
        didSet{textView.backgroundColor = backgroundColor}
    }
    public var fontColor: UIColor{
        get{return (fontAttributes[.foregroundColor] as? UIColor) ?? .black}
        set{
            fontAttributes[.foregroundColor] = newValue
            textView.layer.borderColor = newValue.cgColor
        }
    }
    public var text: String{
        get{return textView.text}
        set{textView.attributedText = NSAttributedString(string: newValue, attributes: fontAttributes)}
    }
    private var textView = UITextView()
    private var grabberView = GrabberView()
    private var liveViewContainer = UIView()
    //MARK: Lifecycle
    final override public func loadView(){
        view = UIView()
        view.addSubview(liveViewContainer)
        view.addSubview(textView)
        view.addSubview(grabberView)
    }
    final override public func viewDidLoad() {
        super.viewDidLoad()
        
        textView.backgroundColor = backgroundColor
        textView.layer.borderWidth = 2
        textView.layer.borderColor = fontColor.cgColor
        textView.layer.cornerRadius = 8
        
        grabberView.backgroundColor = .clear
        
        #if !arch(x86_64)
            pin(to: liveViewSafeAreaGuide)
        #endif
        
        textView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panRecognized(_:))))
        grabberView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panRecognized(_:))))
        
        setupConstraints()
    }
    final override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        liveViewLoader?()
        liveViewLoader = nil
    }
    //MARK: Constraints
    private var consoleShownConstraint: NSLayoutConstraint?
    private var consoleHiddenConstraint: NSLayoutConstraint?
    private var consoleIsHidden = true{
        didSet{swap(&consoleShownConstraint!.isActive, &consoleHiddenConstraint!.isActive)}
    }
    private func setupConstraints(){
        consoleHiddenConstraint = textView.leftAnchor.constraint(equalTo: view.rightAnchor)
        consoleShownConstraint = textView.leftAnchor.constraint(equalTo: view.leftAnchor)
        
        [liveViewContainer, textView, grabberView].forEach{$0.translatesAutoresizingMaskIntoConstraints = false}
        
        NSLayoutConstraint.activate([
            liveViewContainer.topAnchor.constraint(equalTo: view.topAnchor),
            liveViewContainer.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            liveViewContainer.leftAnchor.constraint(equalTo: view.leftAnchor),
            liveViewContainer.rightAnchor.constraint(equalTo: view.rightAnchor),
            textView.topAnchor.constraint(equalTo: view.topAnchor),
            textView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            textView.rightAnchor.constraint(equalTo: view.rightAnchor),
            consoleHiddenConstraint!,
            grabberView.widthAnchor.constraint(equalToConstant: 50),
            grabberView.heightAnchor.constraint(equalToConstant: 60),
            grabberView.rightAnchor.constraint(equalTo: textView.leftAnchor),
            grabberView.topAnchor.constraint(equalTo: textView.topAnchor, constant: 60)
            ])
    }
    //MARK: Animation
    private var consoleViewWidth: CGFloat{
        return (view?.frame.width ?? 0)
    }
    private var layoutAnimator: UIViewPropertyAnimator?
    private var newLayoutAnimator: UIViewPropertyAnimator{
        return UIViewPropertyAnimator.runningPropertyAnimator(
            withDuration: 0.5,
            delay: 0,
            options: [.allowUserInteraction, .layoutSubviews, .beginFromCurrentState],
            animations: {[unowned self] in
                self.view?.layoutIfNeeded()
            },
            completion: {[unowned self] _ in
                self.layoutAnimator = nil
        })
    }
    @objc private func panRecognized(_ recognizer: UIPanGestureRecognizer) {
        switch recognizer.state{
        case .began:
            consoleIsHidden = !consoleIsHidden
            if layoutAnimator == nil{
                layoutAnimator = newLayoutAnimator
            }
        case .changed:
            layoutAnimator?.pauseAnimation()
            var trans = recognizer.translation(in: view).x
            if !consoleIsHidden{
                trans *= -1
            }
            layoutAnimator?.fractionComplete = max(trans/consoleViewWidth, 0)
        case .ended:
            var trans = recognizer.translation(in: view).x
            if !consoleIsHidden{
                trans *= -1
            }
            var fraction = layoutAnimator?.fractionComplete ?? 1
            if fraction < 0.5{
                layoutAnimator?.isReversed = true
                layoutAnimator?.addCompletion{[unowned self] _ in
                    self.consoleIsHidden = !self.consoleIsHidden
                }
                fraction = 1 - fraction
            }
            layoutAnimator?.startAnimation()
        default:
            layoutAnimator?.startAnimation()
        }
    }
    //MARK: Live view setup
    private var liveViewLoader: (()->Void)?
    private func setup(with viewable: PlaygroundLiveViewable?){
        let newView: UIView
        switch liveView {
        case let v as UIView:
            newView = v
        case let viewController as UIViewController:
            newView = viewController.view
        default:
            return
        }
        liveViewLoader = {[weak self] in
            self?.liveViewContainer.addSubview(newView)
        }
    }
    //MARK: Constrain to "safe area guide" on iPad
    private func pin(to guide: UILayoutGuide){
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.topAnchor.constraint(equalTo: guide.topAnchor),
            view.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
            view.leftAnchor.constraint(equalTo: guide.leftAnchor),
            view.rightAnchor.constraint(equalTo: guide.rightAnchor),
            ])
    }
}

#if !arch(x86_64)
    extension ConsoleViewController: PlaygroundLiveViewSafeAreaContainer{}
#endif

//MARK: Console Injection
public extension PlaygroundPage{
    public static let console = ConsoleViewController()
    public var consoleLiveView: PlaygroundLiveViewable?{
        get{
            return PlaygroundPage.console.liveView
        }
        set{
            PlaygroundPage.console.liveView = newValue
            PlaygroundPage.current.liveView = PlaygroundPage.console
        }
    }
}
//MARK: Override default print function - call Swift.print(:) to get default behavior
public func print(_ items: Any...){
    var s = ""
    if items.count == 1{
        Swift.print(items.first!, to: &s)
    }else{
        Swift.print(items, to: &s)
    }
    PlaygroundPage.console.text += s
}

