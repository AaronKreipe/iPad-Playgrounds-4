// vForce.Playground
// use vForce with Swift Arrays
// 2018 @AaronKreipe
import Foundation

// ceil
var x = [1.2, 5.5, 3.9, 26.0]
print(x.roundedUp)

// floor
x = [1.2, 5.5, 3.9, 26.0]
print(x.roundedDown)

// copysign
x = [-1, -1, 1, 1]
var y = [1.2, 5.5, -16, 26]
print(y.copyingSigns(from: x))

// div
x = [1, 2, 2, 4]
y = [1, 1, 10, 30]
print(y.dividing(by: x))

// fabs
x = [-1.2, 5.5, -3.9, 26.0]
print(x.absoluteValues)

// mod
x = [7, 4, 3, 4]
y = [2, 5, 10, 30]
print(y.moduli(dividingBy: x))

// remainder
x = [7, 4, 3, 4]
y = [2, 5, 10, 30]
print(y.remainders(dividingBy: x))

// int
x = [1.2, 5.5, 3.9, 26.9]
print(x.truncatedIntegerValues)

// nint
x = [1.2, 5.5, 3.9, 26.9]
print(x.nearestIntegerValues)

// rsqrt
x = [100, 10000, 64, 144]
print(x.reciprocalSquareRoots)
