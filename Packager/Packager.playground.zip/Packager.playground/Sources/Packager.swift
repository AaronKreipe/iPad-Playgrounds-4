

import Foundation
import UIKit

public extension UIActivityType{
    public static let shareToiCloud = UIActivityType(
        rawValue: "com.apple.CloudDocsUI.AddToiCloudDrive"
    )
}

public class PlaygroundBuilderViewController:
    UIViewController, 
    UIActivityItemSource
{
    private let imageDataString =  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAAAAAA6fptVAAAACklEQVR4nGNiAAAABgADNjd8qAAAAABJRU5ErkJggg=="
    private lazy var console: UITextView = {
        let textView = UITextView()
        textView.backgroundColor = .black
        textView.textColor = .green
        textView.font = UIFont(name: "courier", size: 8)
        
        return textView
    }()
    override public func loadView(){
        view = console
    }
    public var builder: PlaygroundBuilder?{
        didSet{
            guard let builder = builder else{return}
            url = builder.url
            if let message = builder.errorMessage{
                console.text = "😡errors:\n" + message
            }else{
                console.text = "😎success\nbuilt: \(builder.url)"
                presentActionSheet()
            }
        }
    }
    private var url = URL(fileURLWithPath: "")
    private func presentActionSheet(){
        let popover = UIActivityViewController(
            activityItems: [self], 
            applicationActivities: nil
        )
        popover.popoverPresentationController?.sourceView = view
        popover.isModalInPopover = true
        popover.modalPresentationStyle = .popover
        present(popover, animated: true) 
    }
    @available(iOSApplicationExtension 6.0, *)
    public func activityViewController(
        _ activityViewController: UIActivityViewController,
        itemForActivityType activityType: UIActivityType?)->Any? {
        return url
    }
    @available(iOSApplicationExtension 6.0, *)
    public func activityViewControllerPlaceholderItem(
        _ activityViewController: UIActivityViewController
        ) -> Any {
        return UIImage(data: Data(base64Encoded: imageDataString)!)!
    }
}

public class PlaygroundBuilder{
    public enum Constants{
        public static let swiftExt = ".swift"
        public static let playgroundExt = ".playground"
        public static let sourcesFolderName = "Sources"
        public static let playgroundContentsFileName = "Contents"
        public static let metaFileName = "contents.xcplayground"
        public static let newPlaygroundContents = """
import Foundation

print("hello world")
"""
        public static let metaDataContents = """
<?xml version="1.0" encoding="UTF-8"?>
<playground requires-full-environment="false" version="5.0" target-platform="ios"/>
"""
    }
    
    public let sources: [Source]
    public struct Source{
        public let name: String
        public let value: String
    }
    public struct Paths{
        public let temp = FileManager.default.temporaryDirectory
        public let container: URL
        public let contents: URL
        public let metaData: URL
        public let sources: URL
        public init(name: String){
            self.container = temp.appendingPathComponent(name + Constants.playgroundExt)
            self.contents = container.appendingPathComponent(Constants.playgroundContentsFileName + Constants.swiftExt)
            self.metaData = container.appendingPathComponent(Constants.metaFileName)
            self.sources = container.appendingPathComponent(Constants.sourcesFolderName)
        }
    }
    public let url: URL
    public let paths: Paths
    public let errorMessage: String?
    public init(
        sources: [URL], 
        names: [String], 
        name: String = "NewlyBuiltPlayground"
        ){
        var errors: [String]?
        func appendError(_ string: String){
            if errors == nil{errors = [string]}
            else{errors?.append(string)}
        }
        var validSources = [Source]()
        // get source data from playground contents
        for (source, name) in zip(sources, names){
            let sourcePath = source.appendingPathComponent(
                Constants.playgroundContentsFileName + Constants.swiftExt
            )
            print(sourcePath)
            do{
                let sourceContents = try String(
                    contentsOf: sourcePath,
                    encoding: .utf8
                )
                validSources.append(
                    Source(
                        name: name,
                        value: sourceContents
                    )
                )
            }catch let error{
                appendError(error.localizedDescription)
            }
        }
        self.sources = validSources
        self.paths = Paths(name: name)
        if validSources.count > 0{
            //create folder structure for new playground sources
            do{
                try FileManager.default.createDirectory(
                    at: paths.sources,
                    withIntermediateDirectories: true,
                    attributes: nil
                )
            }catch let error{
                appendError(error.localizedDescription)
            }
        }else{
            appendError("no sources found!")
        }
        func write(_ string: String, to url: URL){
            do{
                try string.write(
                    to: url,
                    atomically: true, 
                    encoding: .utf8
                )
            }catch let error{
                appendError(error.localizedDescription)
            }
        }
        // write out data
        write(Constants.newPlaygroundContents, to: paths.contents)
        write(Constants.metaDataContents, to: paths.metaData)
        for source in validSources{
            
            let sourcePath = paths.sources.appendingPathComponent(
                source.name + Constants.swiftExt
            )
            write(source.value, to: sourcePath)
        }
        url = paths.container
        errorMessage = errors?.joined(separator: "\n")
    }
}



