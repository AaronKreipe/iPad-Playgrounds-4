import UIKit

public let HELLO_WORLD = "hello world"

public class LazyViewController: UIViewController{
    lazy var lazyView: UIView = {
        return UIView()
    }()
    override public func loadView(){
        view = lazyView
    }
}

