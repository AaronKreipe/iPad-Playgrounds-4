// Packager.playground
// package source files into new playground
// 2017 @AaronKreipe
import PlaygroundSupport


// add source files from [+] button above
// input names for new .swift files
// name your new playground file
let builder = PlaygroundBuilder(sources: [#fileLiteral(resourceName: "TestPlayground.playground")], names: ["Test"], name: "Packager Test")


// create builder vc
let vc = PlaygroundBuilderViewController()
// set to liveview for console output
PlaygroundPage.current.liveView = vc
// lets do this!
vc.builder = builder
