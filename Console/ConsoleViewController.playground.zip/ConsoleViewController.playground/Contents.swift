// Console For Swift Playgrounds
// Aaron Kreipe 2017

import UIKit
import PlaygroundSupport

// configure console how you like
PlaygroundPage.console.backgroundColor = .black
PlaygroundPage.console.fontColor = .green
PlaygroundPage.console.fontAttributes[.font] = UIFont(name: "Courier", size: 12)

// create a view or view controller
let vc = UITableViewController()
vc.tableView.cellLayoutMarginsFollowReadableWidth = false

// use consoleLiveView property to inject console
PlaygroundPage.current.consoleLiveView = vc

// print as normal
print("hello swift", "thanks ")
print(14 + 7 + 21)
